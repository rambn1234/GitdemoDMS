package com.cjc;

import java.io.Serializable;

public class Account implements Serializable{
	
	String uname="Nikhil";
	
	transient String pwd="chaudhari" ;

}
