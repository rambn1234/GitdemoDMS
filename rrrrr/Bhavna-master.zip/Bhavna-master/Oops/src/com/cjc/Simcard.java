package com.cjc;

public class Simcard extends Mobile{
	
	public Object m1()
	{
		return "Ram";
	}

}
