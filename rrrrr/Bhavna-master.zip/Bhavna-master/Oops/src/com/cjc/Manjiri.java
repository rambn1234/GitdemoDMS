package com.cjc;

public class Manjiri {
	

	
	  static {
		  
		  System.out.println("static of manjiri");
	  }
	  {
		  System.out.println("non munnu");
	  }
	  
	   public Manjiri() {
	   
	    System.out.println("constructor of Manjiri");
	   
	   }  
    	  
	  
	  
}
	
	
	



