package com.cjc;

public class Mobile {
	
	    protected Object m1()
	     {
	    	 System.out.println("m1 of Mobile");
	    	 return "Nikhil";
	     }
	
	

}
