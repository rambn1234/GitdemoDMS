package com.cjc;

public class Nikhil  {

	static int y=20;
	
	public static void main(String[] args) {
		
		Nikhil Nik=new Nikhil();
		Nikhil Nik1=new Nikhil();
	
		System.out.println(Nik.y);
		System.out.println(Nik1.y);
		
		Nik.y=40;
		
		System.out.println(Nik1.y);
		System.out.println(Nik.y);
			
	}

}
