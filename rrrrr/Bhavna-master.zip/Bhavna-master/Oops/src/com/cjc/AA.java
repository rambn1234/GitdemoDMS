package com.cjc;

public class AA {
	
	public static void main(String[] args) {
		
		
		StringBuffer sb=new StringBuffer("Nikhil");
		
		
		StringBuffer sb1=new StringBuffer("Nikhi");
		
		System.out.println(sb1.equals(sb));
		System.out.println(sb1==sb);
	
	
}}
