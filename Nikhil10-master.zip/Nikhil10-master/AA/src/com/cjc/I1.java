package com.cjc;

public interface I1 {
	
	default void m1()
	{
		System.out.println("aa");
	}
	
	
	
}